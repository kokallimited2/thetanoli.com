/**
 * Property Search Engine — Cloudflare Worker
 * 
 * Routes:
 *   POST /api/search-by-postcode — Search properties in a postcode area
 *   POST /api/search-by-url — Analyse a single property from Rightmove/Zoopla URL
 *   GET /api/lists — Get available property strategy lists
 *   GET /api/property-health — Check if PropertyData API key is working
 * 
 * Environment Variables (set in Cloudflare Dashboard):
 *   PROPERTYDATA_API_KEY — Your PropertyData API key
 *   PROPERTYDATA_BASE_URL — https://api.propertydata.co.uk
 */

import { analyseProperty } from './analysis';

// ─── Request Router ───────────────────────────────────────────────────────────

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    const path = url.pathname;

    // CORS headers for frontend
    const corsHeaders = {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type',
    };

    if (request.method === 'OPTIONS') {
      return new Response(null, { headers: corsHeaders });
    }

    try {
      switch (path) {
        case '/api/search-by-postcode':
          return handlePostcodeSearch(request, env, corsHeaders);
        
        case '/api/search-by-url':
          return handleUrlSearch(request, env, corsHeaders);
        
        case '/api/lists':
          return handleGetLists(env, corsHeaders);
        
        case '/api/property-health':
          return handleHealthCheck(env, corsHeaders);
        
        default:
          return new Response(
            JSON.stringify({ error: 'Not found', endpoints: ['/api/search-by-postcode', '/api/search-by-url', '/api/lists', '/api/property-health'] }),
            { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
          );
      }
    } catch (err) {
      return new Response(
        JSON.stringify({ error: err.message }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }
  }
};

// ─── Handlers ─────────────────────────────────────────────────────────────────

async function handlePostcodeSearch(request, env, corsHeaders) {
  const body = await request.json();
  const { postcode, list = 'unmodernised-properties', radius = 20, max_results = 20, max_price, min_bedrooms } = body;

  if (!postcode) {
    return new Response(
      JSON.stringify({ error: 'postcode is required' }),
      { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }

  // Step 1: Fetch sourced properties from PropertyData
  const properties = await fetchSourcedProperties(env.PROPERTYDATA_API_KEY, {
    postcode, list, radius, max_results
  });

  if (!properties || properties.length === 0) {
    return new Response(
      JSON.stringify({ properties: [], analysis: null, message: 'No properties found in this area for the selected strategy.' }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }

  // Step 2: Fetch area-level market data (1 call for the postcode, not per property)
  const areaData = await fetchAreaData(env.PROPERTYDATA_API_KEY, postcode);

  // Step 3: Analyse each property
  let analysed = properties.map(p => ({
    ...p,
    analysis: analyseProperty(p, areaData)
  }));

  // Step 4: Apply additional filters
  if (max_price) {
    analysed = analysed.filter(p => p.price <= parseInt(max_price));
  }
  if (min_bedrooms) {
    analysed = analysed.filter(p => p.bedrooms >= parseInt(min_bedrooms));
  }

  // Step 5: Sort by recommendation score (highest first)
  analysed.sort((a, b) => b.analysis.score - a.analysis.score);

  return new Response(
    JSON.stringify({
      properties: analysed.slice(0, 20),
      area: areaData,
      total_found: properties.length,
      total_analysed: analysed.length,
    }),
    { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
  );
}

async function handleUrlSearch(request, env, corsHeaders) {
  const body = await request.json();
  const { url } = body;

  if (!url) {
    return new Response(
      JSON.stringify({ error: 'url is required — paste a Rightmove or Zoopla listing URL' }),
      { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }

  // Extract property ID from URL
  const { platform, propertyId } = parsePropertyUrl(url);
  
  if (!propertyId) {
    return new Response(
      JSON.stringify({ error: 'Could not extract property ID from URL. Make sure it\'s a valid Rightmove or Zoopla listing.' }),
      { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }

  // PropertyData uses their own ID format (R-prefixed for Rightmove sourced)
  // If user pastes a standard Rightmove URL, we map it
  // For Rightmove: property ID is numeric (e.g. 168299921)
  // PropertyData prefix depends on how they ingested it
  
  // Try fetching by sourced-property first
  let property = null;
  try {
    const pdId = `R${propertyId}`;
    property = await fetchSourcedProperty(env.PROPERTYDATA_API_KEY, pdId);
  } catch (e) {
    // Not in their sourced listings — that's fine, we'll still get area analysis
  }

  // Get postcode from property or prompt the user
  let postcode = property?.postcode || body.postcode;
  
  if (!postcode) {
    return new Response(
      JSON.stringify({ 
        error: 'postcode_required', 
        message: 'This property wasn\'t found in PropertyData\'s sourced listings. Please provide a postcode for area analysis.',
        property: property || { platform, id: propertyId }
      }),
      { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }

  // Fetch area data for valuation
  const areaData = await fetchAreaData(env.PROPERTYDATA_API_KEY, postcode);

  // Analyse the single property
  const analysis = property 
    ? analyseProperty(property, areaData)
    : { score: 0, verdict: 'INSUFFICIENT_DATA', notes: 'Property not found in sourced listings. Area analysis provided below.', areaData };

  return new Response(
    JSON.stringify({
      property,
      platform,
      url,
      analysis,
      area: areaData,
    }),
    { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
  );
}

async function handleGetLists(env, corsHeaders) {
  return new Response(
    JSON.stringify({ lists: PROPERTY_LISTS }),
    { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
  );
}

async function handleHealthCheck(env, corsHeaders) {
  try {
    const resp = await fetch(`https://api.propertydata.co.uk/sourced-properties?key=${env.PROPERTYDATA_API_KEY}&list=unmodernised-properties&postcode=OX3+9DW&radius=1&results=1`);
    const data = await resp.json();
    return new Response(
      JSON.stringify({ status: 'ok', propertydata: data.status === 'success' ? 'connected' : 'error', detail: data }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (e) {
    return new Response(
      JSON.stringify({ status: 'error', message: e.message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
}

// ─── PropertyData API Calls ───────────────────────────────────────────────────

async function fetchSourcedProperties(apiKey, { postcode, list, radius, max_results }) {
  const url = `https://api.propertydata.co.uk/sourced-properties?key=${apiKey}&list=${list}&postcode=${encodeURIComponent(postcode)}&radius=${radius}&results=${max_results}`;
  
  const resp = await fetch(url);
  const data = await resp.json();

  if (data.status !== 'success' || !data.properties) {
    throw new Error(data.message || 'PropertyData API returned an error');
  }

  return data.properties.map(p => ({
    id: p.id,
    address: p.address,
    precise_address: p.precise_address,
    postcode: p.postcode,
    type: p.type,
    type_standardised: p.type_standardised,
    bedrooms: p.bedrooms,
    price: p.price,
    sqf: p.sqf,
    ppsf: p.price && p.sqf ? Math.round(p.price / p.sqf) : null,
    days_on_market: p.days_on_market,
    days_since_price_change: p.days_since_price_change,
    sstc: p.sstc,
    lat: p.lat,
    lng: p.lng,
    distance: p.distance_to,
    price_history: p.price_history || [],
    image_url: p.image_url,
    summary: p.summary,
    listing_url: p.url,
  }));
}

async function fetchSourcedProperty(apiKey, propertyId) {
  const url = `https://api.propertydata.co.uk/sourced-property?key=${apiKey}&id=${propertyId}`;
  const resp = await fetch(url);
  const data = await resp.json();

  if (data.status !== 'success' || !data.property) {
    throw new Error('Property not found');
  }

  return {
    ...data.property,
    ppsf: data.property.price && data.property.sqf ? Math.round(data.property.price / data.property.sqf) : null,
  };
}

async function fetchAreaData(apiKey, postcode) {
  // Fetch area-level stats in parallel
  const [yieldsResp, growthResp, pricesResp, rentsResp] = await Promise.allSettled([
    fetch(`https://api.propertydata.co.uk/yields?key=${apiKey}&postcode=${encodeURIComponent(postcode)}`),
    fetch(`https://api.propertydata.co.uk/growth?key=${apiKey}&postcode=${encodeURIComponent(postcode)}`),
    fetch(`https://api.propertydata.co.uk/prices?key=${apiKey}&postcode=${encodeURIComponent(postcode)}`),
    fetch(`https://api.propertydata.co.uk/valuation-rent?key=${apiKey}&postcode=${encodeURIComponent(postcode)}`),
  ]);

  const parseJson = async (result) => {
    if (result.status === 'fulfilled') {
      try { return await result.value.json(); } catch { return null; }
    }
    return null;
  };

  return {
    yields: await parseJson(yieldsResp),
    growth: await parseJson(growthResp),
    prices: await parseJson(pricesResp),
    rents: await parseJson(rentsResp),
  };
}

// ─── URL Parsing ──────────────────────────────────────────────────────────────

function parsePropertyUrl(url) {
  // Rightmove: https://www.rightmove.co.uk/properties/168299921
  let match = url.match(/rightmove\.co\.uk\/properties\/(\d+)/i);
  if (match) return { platform: 'rightmove', propertyId: match[1] };

  // Rightmove: https://www.rightmove.co.uk/property-for-sale/property-12345.html
  match = url.match(/rightmove\.co\.uk\/.*?property[-]?(\d+)/i);
  if (match) return { platform: 'rightmove', propertyId: match[1] };

  // Zoopla: https://www.zoopla.co.uk/for-sale/details/12345678
  match = url.match(/zoopla\.co\.uk\/.*?\/(\d{6,10})/i);
  if (match) return { platform: 'zoopla', propertyId: match[1] };

  return { platform: null, propertyId: null };
}

// ─── Property Strategy Lists ──────────────────────────────────────────────────

const PROPERTY_LISTS = [
  { id: 'unmodernised-properties', name: 'Unmodernised Properties', desc: 'Needs renovation — ideal for BRRR and flip' },
  { id: 'repossessed-properties', name: 'Repossessed Properties', desc: 'Bank/mortgage repossession — motivated seller' },
  { id: 'cash-buyers-only-properties', name: 'Cash Buyers Only', desc: 'No mortgage chain — quick completion possible' },
  { id: 'auction-properties', name: 'Auction Properties', desc: 'Forced sale timeline — potential bargains' },
  { id: 'slow-to-sell-properties', name: 'Slow to Sell', desc: '180+ days on market — motivated vendor' },
  { id: 'reduced-properties', name: 'Recently Reduced', desc: 'Price dropped — potential value play' },
  { id: 'back-on-market', name: 'Back on Market', desc: 'Sale fell through — vendor wants quick sale' },
  { id: 'derelict-properties', name: 'Derelict Properties', desc: 'Full renovation needed — max value add' },
  { id: 'cheap-per-square-foot', name: 'Cheap per sqft', desc: 'Below-average £/sqft — value opportunity' },
  { id: 'short-lease-properties', name: 'Short Lease', desc: 'Lease <80 years — discount potential' },
  { id: 'high-yield-properties', name: 'High Yield', desc: 'Pre-filtered for strong rental yield' },
  { id: 'high-rental-demand', name: 'High Rental Demand', desc: 'Strong letting market in the area' },
  { id: 'tenanted-properties-for-sale', name: 'Tenanted', desc: 'Sitting tenants — immediate rental income' },
  { id: 'hmo-licenced-properties', name: 'HMO Licensed', desc: 'Already HMO compliant' },
  { id: 'holiday-let-properties', name: 'Holiday Let / Airbnb', desc: 'Short-term let potential' },
  { id: 'investment-portfolios', name: 'Investment Portfolios', desc: 'Multi-unit or portfolio sales' },
  { id: 'properties-with-no-chain', name: 'No Chain', desc: 'Faster transaction — no onward purchase' },
  { id: 'properties-with-planning-granted', name: 'Planning Granted', desc: 'Permission already approved — development ready' },
  { id: 'land-plots-for-sale', name: 'Land / Plots', desc: 'Development land and building plots' },
  { id: 'poor-epc-score', name: 'Poor EPC', desc: 'EPC band F/G — renovation opportunity' },
  { id: 'suitable-for-splitting', name: 'Suitable for Splitting', desc: 'Title splitting / house in multiple parts' },
  { id: 'properties-with-an-annexe', name: 'With Annexe', desc: 'Multi-income potential from annexe' },
  { id: 'mixed-use', name: 'Mixed Use', desc: 'Commercial + residential — higher yield potential' },
  { id: 'bungalows-for-sale', name: 'Bungalows', desc: 'Extension / development potential' },
  { id: 'unbroken-freeholds', name: 'Freehold Only', desc: 'No leasehold complications' },
  { id: 'walking-distance-to-town-centre', name: 'Walk to Town Centre', desc: 'Prime location — lettability' },
  { id: 'properties-near-a-university', name: 'Near University', desc: 'Student let potential' },
  { id: 'near-large-development', name: 'Near Development', desc: 'Capital growth from area regeneration' },
  { id: 'properties-near-great-school', name: 'Near Great School', desc: 'Family rental / resale premium' },
  { id: 'high-population-growth', name: 'High Population Growth', desc: 'Growing area — capital appreciation' },
];
