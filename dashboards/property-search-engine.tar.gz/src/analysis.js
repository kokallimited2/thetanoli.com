/**
 * Property Analysis Engine
 * 
 * Takes a property + area data → calculates viability scores
 * for BRRR, BTL, and Flip strategies.
 */

export function analyseProperty(property, areaData) {
  const scores = {};
  const notes = [];

  // ─── BRRR Score ─────────────────────────────────────────────────────
  scores.brrr = calculateBrrrScore(property, areaData, notes);

  // ─── BTL Yield Score ────────────────────────────────────────────────
  scores.btl = calculateBtlScore(property, areaData, notes);

  // ─── Flip Score ─────────────────────────────────────────────────────
  scores.flip = calculateFlipScore(property, areaData, notes);

  // ─── Overall Score ──────────────────────────────────────────────────
  const overall = Math.round((scores.brrr * 0.35 + scores.btl * 0.30 + scores.flip * 0.35) * 100) / 100;

  // ─── Verdict ────────────────────────────────────────────────────────
  const verdict = overall >= 75 ? 'STRONG_BUY' 
    : overall >= 60 ? 'BUY' 
    : overall >= 40 ? 'NEUTRAL' 
    : 'PASS';

  const badge = overall >= 75 ? '🟢' : overall >= 60 ? '🟡' : overall >= 40 ? '🟠' : '🔴';

  // ─── Key Metrics ────────────────────────────────────────────────────
  const metrics = {
    price: property.price,
    sqf: property.sqf,
    ppsf: property.ppsf,
    days_on_market: property.days_on_market,
    sstc: property.sstc,
    price_changes: property.price_history?.length || 0,
    price_reduction: getPriceReduction(property),
    estimated_monthly_rent: areaData?.yields?.estimated_rent || areaData?.rents?.estimated_rent || null,
    area_gross_yield: areaData?.yields?.gross_yield || null,
    area_growth_5y: areaData?.growth?.growth_5y || null,
    area_avg_price: areaData?.prices?.average_price || null,
  };

  return {
    overall,
    verdict,
    badge,
    scores,
    metrics,
    notes: notes.slice(0, 5),
    recommendation: getRecommendation(verdict, property, metrics),
  };
}

// ─── Scoring Functions ────────────────────────────────────────────────────────

function calculateBrrrScore(property, areaData, notes) {
  let score = 50;
  const reasons = [];

  // Unmodernised/derelict = good for BRRR (more value to add)
  if (property.type_standardised && 
      ['terrace', 'terraced_house', 'semi_detached', 'semi-detached_house'].includes(property.type_standardised)) {
    score += 10;
    reasons.push('Standard property type — easier refurb cost estimation');
  }

  // Days on market — longer = more motivated seller
  if (property.days_on_market >= 180) {
    score += 15;
    reasons.push('180+ days on market — motivated seller');
  } else if (property.days_on_market >= 90) {
    score += 8;
    reasons.push('90+ days — possible negotiation room');
  }

  // Price reduction signals
  const reduction = getPriceReduction(property);
  if (reduction && reduction.percent > 5) {
    score += 10;
    reasons.push(`Price reduced ${reduction.percent}% — good negotiation starting point`);
  }

  // Not SSTC = still available
  if (!property.sstc) {
    score += 5;
  } else {
    score -= 20;
    reasons.push('Sold Subject to Contract — cannot buy');
  }

  // Area growth — positive = BRRR exit easier
  if (areaData?.growth?.growth_5y && areaData.growth.growth_5y > 15) {
    score += 8;
    reasons.push(`Strong 5yr growth (${areaData.growth.growth_5y}%) — good exit prospects`);
  } else if (areaData?.growth?.growth_5y && areaData.growth.growth_5y < 0) {
    score -= 10;
    reasons.push(`Negative area growth (${areaData.growth.growth_5y}%) — BRRR exit risk`);
  }

  // Has square footage = easier to estimate refurb
  if (property.sqf) {
    score += 7;
    reasons.push(`Known sqft (${property.sqf}) — better cost estimation`);
  }

  notes.push(...reasons);
  return Math.max(0, Math.min(100, score));
}

function calculateBtlScore(property, areaData, notes) {
  let score = 50;
  const reasons = [];

  // Rental yield
  const yield_est = areaData?.yields?.gross_yield;
  if (yield_est) {
    if (yield_est >= 7) {
      score += 20;
      reasons.push(`Gross yield ${yield_est}% — strong for BTL`);
    } else if (yield_est >= 5) {
      score += 10;
      reasons.push(`Gross yield ${yield_est}% — viable for BTL`);
    } else {
      score -= 10;
      reasons.push(`Gross yield ${yield_est}% — below 5% threshold`);
    }
  }

  // Rental demand
  if (areaData?.yields?.demand_level) {
    if (areaData.yields.demand_level === 'high') {
      score += 10;
      reasons.push('High rental demand in area');
    } else if (areaData.yields.demand_level === 'low') {
      score -= 10;
      reasons.push('Low rental demand — potential void risk');
    }
  }

  // Bedroom count — 2-3 beds are most lettable
  if (property.bedrooms >= 2 && property.bedrooms <= 3) {
    score += 8;
    reasons.push(`${property.bedrooms} beds — strong rental demographics`);
  } else if (property.bedrooms === 1) {
    score -= 5;
    reasons.push('1 bed — limited tenant pool');
  }

  // Cash buyer only = harder to leverage BTL mortgage
  // (we can't detect this from the API response directly, but we can note it)
  
  // SSTC check
  if (property.sstc) {
    score -= 15;
    reasons.push('SSTC — cannot proceed');
  }

  notes.push(...reasons);
  return Math.max(0, Math.min(100, score));
}

function calculateFlipScore(property, areaData, notes) {
  let score = 50;
  const reasons = [];

  // For flipping, we need a discount to market
  const avgPrice = areaData?.prices?.average_price;
  if (avgPrice && property.price) {
    const discount = ((avgPrice - property.price) / avgPrice) * 100;
    if (discount > 20) {
      score += 25;
      reasons.push(`Listed ${Math.round(discount)}% below area avg — flip potential`);
    } else if (discount > 10) {
      score += 15;
      reasons.push(`Listed ${Math.round(discount)}% below area avg — possible deal`);
    } else if (discount < -10) {
      score -= 15;
      reasons.push(`Listed above area average — harder flip margin`);
    }
  }

  // Days on market — longer = more negotiable
  if (property.days_on_market >= 180) {
    score += 10;
    reasons.push('Long market time — vendor may accept low offer');
  }

  // Price reductions — confirms negotiation room
  const reduction = getPriceReduction(property);
  if (reduction) {
    score += Math.min(10, reduction.percent);
    if (reduction.percent > 5) {
      reasons.push(`Reduced ${reduction.percent}% — confirms overpriced originally`);
    }
  }

  // Type check — houses flip better than flats
  if (property.type_standardised && 
      ['terrace', 'terraced_house', 'semi_detached', 'semi-detached_house', 'detached_house'].includes(property.type_standardised)) {
    score += 8;
    reasons.push('House — better flip liquidity than flat');
  }

  // Area growth — positive = easier to sell after flip
  if (areaData?.growth?.growth_5y && areaData.growth.growth_5y > 10) {
    score += 7;
    reasons.push(`Growth area (${areaData.growth.growth_5y}%) — good exit`);
  }

  notes.push(...reasons);
  return Math.max(0, Math.min(100, score));
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

function getPriceReduction(property) {
  if (!property.price_history || property.price_history.length < 2) return null;
  
  const firstPrice = property.price_history[0].price;
  const currentPrice = property.price;
  
  if (firstPrice > currentPrice) {
    return {
      original: firstPrice,
      current: currentPrice,
      difference: firstPrice - currentPrice,
      percent: Math.round(((firstPrice - currentPrice) / firstPrice) * 100),
    };
  }
  return null;
}

function getRecommendation(verdict, property, metrics) {
  const lines = [];
  
  if (verdict === 'STRONG_BUY') {
    lines.push(`Strong buy candidate at £${(property.price / 1000).toFixed(0)}k`);
  } else if (verdict === 'BUY') {
    lines.push(`Potential deal — worth investigating further`);
  } else if (verdict === 'NEUTRAL') {
    lines.push(`Average — only pursue if it meets your specific criteria`);
  } else {
    lines.push(`Skip — does not meet minimum deal criteria`);
  }

  if (metrics.area_gross_yield) {
    lines.push(`Area yield: ${metrics.area_gross_yield}%`);
  }
  if (metrics.area_growth_5y) {
    lines.push(`5yr growth: ${metrics.area_growth_5y}%`);
  }
  if (property.days_on_market > 0) {
    lines.push(`On market: ${property.days_on_market} days`);
  }

  return lines.join(' · ');
}
